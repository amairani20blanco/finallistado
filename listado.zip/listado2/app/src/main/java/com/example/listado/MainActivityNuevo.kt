package com.example.listado

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.listado.databinding.ActivityMainNuevoBinding

class MainActivityNuevo : AppCompatActivity() {
    private lateinit var binding: ActivityMainNuevoBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainNuevoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //abrimos la conexion
        val dbconx = DBHelperAlumnos(this)
        val intento2 = Intent(this, MainActivity::class.java)
        binding.btnGuardar.setOnClickListener {


        }
        //abrimos la base de datos para escribir
        val db = dbconx.writableDatabase
        val txtNombre = binding.txtNombre.text.toString()
        val txtCuenta = binding.txtCuenta.text.toString()
        val txtCorreo = binding.txtCorreo.text.toString()
        val txtImagen = binding.txtImagen.text.toString()

        //alternativa 1
        //val sql = "INSERT INTO alumnos(nombre, cuenta correo imagen) VALUES ('$txtNombre', '$txtCuenta', '$txtCorreo', '$txtImagen')"
        //val result = db.execSQL(sql)

        //alternativa 2
        val newReg = ContentValues()
        newReg.put("nombre", txtNombre)
        newReg.put("cuenta", txtCuenta)
        newReg.put("correo", txtCorreo)
        newReg.put("imagen", txtImagen)

        val res = db.insert("alumnos", null, newReg)

        if (res.toInt() == -1) {
            Toast.makeText(this, "Error al insertar", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Registro insertado", Toast.LENGTH_LONG).show()
            startActivity(intento2)
        }
    }

/*
        val parExtra = intent.extras
        //var miVar = parExtra?.getString("valor1")

        //binding.txtDato.text= miVar.toString()


            intento2.putExtra("mensaje","nuevo")
            intento2.putExtra("nombre","${txtNombre}")
            intento2.putExtra("cuenta","${txtCuenta}")
            intento2.putExtra("correo","${txtCorreo}")
            intento2.putExtra("imagen","${txtImagen}")

        }
*/
    }
}